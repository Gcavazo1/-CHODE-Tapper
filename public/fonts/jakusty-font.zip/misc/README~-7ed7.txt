
[By installing or using this font, you are agree to the Product Usage Agreement]

=============================== [ 0 ] =========================================
	    This font is for PERSONAL USE ONLY (Non-Profit Activity).
	          [ NOT ALLOWED for Commercial Use ] in any form.
===============================================================================


Paypal account donation for supporting us : https://paypal.me/jadaakbal
Any amount of donation will be greatly appreciated :).
 
=============================== [ 1 ] =========================================

if you are interested in buying it, contact me for detailed license : jadaakbaaal@gmail.com

============================ Thank you ========================================
